/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.utilities.custom.postgress;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.usertype.UserType;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
 

public class JSONUserType implements UserType {
 
  private static final int[] SQL_TYPES = { Types.JAVA_OBJECT };
  
  
  @Override
  public int[] sqlTypes() {
    return SQL_TYPES;
  }
  
  
  @Override
  public Class<JSONObject> returnedClass() {
    return JSONObject.class;
  }
  
 
  @Override
  public boolean equals(Object x, Object y) throws HibernateException {
    if (x == null) return (y == null);
    return (x.equals(y));
  }
  
  
  @Override
  public int hashCode(Object x) throws HibernateException {
    return x.hashCode();
  }
  
  
  @Override
  public Object nullSafeGet(ResultSet rs, String[] names,SessionImplementor session, Object owner) throws HibernateException, SQLException {
    if (rs.getString(names[0])!=null) {
    	final JSONParser parser = new JSONParser();
    	try {
    		return parser.parse(rs.getString(names[0]));
    	} catch (final ParseException pe) {
    		throw new HibernateException(pe);
    	}
    }
    return new JSONObject();
  }
 
    
  
  @Override
  public void nullSafeSet(PreparedStatement st, Object value, int index,SessionImplementor session) throws HibernateException, SQLException {
    if (value == null) {
      st.setNull(index, Types.OTHER);
    } else {
      st.setObject(index, value.toString(),Types.OTHER);
    }
  }
  
  
    @Override
  public Object deepCopy(Object value) throws HibernateException {
    if (value == null) return value;
    
	final JSONParser parser = new JSONParser();
	try {
		return parser.parse(value.toString());
	} catch (final ParseException pe) {
		throw new HibernateException(pe);
	}
  }
 
  
   @Override
  public boolean isMutable() {
    return true;
  }
   
   
     @Override
  public Serializable disassemble(Object value) throws HibernateException {
    return value.toString();
  }
   
     
     
  @Override
  public Object assemble(Serializable cached, Object owner) throws HibernateException {
    return deepCopy(cached);
  }
 
  
  

  
   
  
  
  @Override
  public Object replace(Object original, Object target, Object owner) throws HibernateException {
    return deepCopy(original);
  }
 

 

 
}
