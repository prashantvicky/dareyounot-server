/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.model;

import java.io.Serializable;

public class Response<T> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// set default value as OK
	private String statusMsg = "OK";
	
	private int statusCode = 200;
	
	private T[] result;

	
	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMessage) {
		this.statusMsg = statusMessage;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public T[] getResult() {
		return result;
	}

	public void setResult(T... result) {
		this.result = result;
	}
}
