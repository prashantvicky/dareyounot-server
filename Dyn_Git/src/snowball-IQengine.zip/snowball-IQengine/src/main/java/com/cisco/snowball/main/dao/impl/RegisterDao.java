/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cisco.snowball.main.dao.IRegisterDao;
import com.cisco.snowball.main.dao.common.AbstractHibernateDao;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.Register;

@Repository
public class RegisterDao extends AbstractHibernateDao<Register>
		implements IRegisterDao {


	@Autowired
	private SessionFactory sessionFactory;

	public RegisterDao() {
		super();

		setClazz(Register.class);
	}

	
	/**
	 * Deletes the Sp details if status is delete pending else updates status to
	 * delete_pending
	 * 
	 * @param id
	 * @param hostName
	 * @return
	 */
	
	public Response deleteById(long id, String hostName)
			throws HibernateException { 
		Register sp = findOne(id);
		Response res = new Response();
		if (sp.getHostName() == null
				|| sp.getHostName().equalsIgnoreCase(hostName)) {
			Query query = sessionFactory.getCurrentSession().createQuery(
					"update Register set status = :status,"
							+ "hostname = :hostname" + " where id = '" + id
							+ "'");
			query.setParameter("status", "DELETE_PENDING");
			query.setParameter("hostname", hostName);
			query.executeUpdate();
			res.setStatusMsg("updated");
		} else {
			
			res = delete(findOne(id));
		}

		return res;
	}


	
	
	
}
