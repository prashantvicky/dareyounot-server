/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.cisco.snowball.main.dao.IRoleDao;
import com.cisco.snowball.main.dao.common.IOperations;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.Role;
import com.cisco.snowball.main.service.IRoleService;
import com.cisco.snowball.main.service.common.AbstractService;
import org.springframework.stereotype.Service;

@Service
public class RoleService extends AbstractService<Role> implements IRoleService {

	@Autowired
	private IRoleDao dao;

	public RoleService() {
		super();
	}
public Response deleteById(long id){
		
		return dao.deleteById(id);
	}
	@Override
	protected IOperations<Role> getDao() {
		return dao;
	}

}
