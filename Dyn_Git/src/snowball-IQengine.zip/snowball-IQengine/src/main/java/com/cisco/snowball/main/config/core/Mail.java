/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */


package com.cisco.snowball.main.config.core;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.*;
import javax.mail.internet.*;

public class Mail
{
    final static private boolean VERBOSE = false;
    final static private boolean DEBUG   = false;

    /**
     * - Send email.
     * - It will make loginUserId to be null.
     *
     * @param  emailSubject     String.
     * @param  recipients       String[]. Required.
     * @param  emailMsg         StringBuffer. Required.
     *
     * @return ---
     */
    public static void sendMail(
                String          emailSubject,
                String          recipients[],
                StringBuffer    emailMsg)
               // String 			osType)
    throws Exception  {


        try {
            String loginUserId  = null;
            Vector emailTos     = new Vector();

            if( recipients!=null && recipients.length>0 )
            {
                for( int i=0; i<recipients.length; i++ )
                {
                    emailTos.addElement(recipients[i]);
                }
            } // if

            sendMail ( loginUserId, emailSubject, emailTos, emailMsg, false );

        } catch (Exception e) {
            e.printStackTrace();
        }

    } // public static void sendMail( emailSubject, recipients[], emailMsg )

    /**
     * - Send email.
     *
     * @param  loginUserId      String. Optional.
     *                              - If null, or "", user-level email check is skipped.
     * @param  emailSubject     String.
     * @param  recipients       String[]. Required.
     * @param  emailMsg         StringBuffer. Required.
     *
     * @return ---
     */
    public static void sendMail(
                String          loginUserId,
                String          emailSubject,
                String          recipients[],
                StringBuffer    emailMsg)
     //           String 			osType)
    throws Exception  {

        try {
            Vector emailTos     = new Vector();

            if( recipients!=null && recipients.length>0 )
            {
                for( int i=0; i<recipients.length; i++ )
                {
                    emailTos.addElement(recipients[i]);
                }
            } // if

            sendMail ( loginUserId, emailSubject, emailTos, emailMsg, false );

        } catch (Exception e) {
            e.printStackTrace();
        }

    } // public static void sendMail( loginUserId, emailSubject, recipients[], emailMsg )

    /**
     * - Send email.
     * - It will make loginUserId to be null.
     *
     * @param  loginUserId      String. Optional.
     *                              - If null, or "", user-level email check is skipped.
     * @param  emailSubject     String.
     * @param  emailTos         Vector. Required.
     * @param  emailMsg         StringBuffer. Required.
     *
     */
    public static void sendMail(
                String          emailSubject,
                Vector          emailTos,
                StringBuffer    emailMsg)
             //   String 			osType)
    throws Exception  {


        try
        {
            String loginUserId  = null;
            sendMail ( loginUserId, emailSubject, emailTos, emailMsg, false );

        } catch (Exception e)  {
            e.printStackTrace();
        }

    } // public static void sendMail( emailSubject, emailTos, emailMsg )

    /**
     * - Send email.
     * - It will make loginUserId to be null.
     *
     * @param  loginUserId      String. Optional.
     *                              - If null, or "", user-level email check is skipped.
     * @param  emailSubject     String.
     * @param  emailTos         Vector. Required.
     * @param  emailMsg         StringBuffer. Required.
     * @param  loginUserId           String. Required.
     *
     */
    public static void sendMail(
                String          loginUserId,
                String          emailSubject,
                Vector          emailTos,
                StringBuffer    emailMsg)
    throws Exception  {


        try
        {

            sendMail ( loginUserId, emailSubject, emailTos, emailMsg,  false );

        } catch (Exception e)  {
            e.printStackTrace();
        }

    } // public static void sendMail( emailSubject, emailTos, emailMsg )

    /**
     *
     * @param  loginUserId      String. Optional.
     *                              - If null, or "", user-level email check is skipped.
     * @param  emailSubject     String. Required.
     * @param  emailTos         Vector. Required.
     * @param  emailMsg         StringBuffer. Required.
     * @param  osType           String. Required.
     *
     */
    public static void sendMail(
                String          loginUserId,
                String          emailSubject,
                Vector          emailTos,  
                StringBuffer    emailMsg,
             //   String          osType,
                boolean 		suppressEmailCC)
    throws Exception  {

        final String THIS_METHOD = "Mail.sendMail";
        String addressCc = null;

        log( "===>" + THIS_METHOD + "( " + loginUserId + ", " + emailSubject +
            ", " + emailTos + ", emailMsg ) BEGIN" );

        if( emailSubject==null || emailSubject.trim().length()==0 )
        {
            throw new Exception( THIS_METHOD + ". Parameter 'emailSubject' is undefined." );
        }

        if( emailTos==null || emailTos.isEmpty() )
        {
            throw new Exception( THIS_METHOD + ". Parameter 'emailTos' is undefined." );
        }

        if( emailMsg==null || emailMsg.length()==0 )
        {
            throw new Exception( THIS_METHOD + ". Parameter 'emailMsg' is undefined." );
        }

        try {
             String dbEnvDesc = "TEST";
            String emailMsgEnv = "This is an automated notification email from ** SNOWBALL " + dbEnvDesc +
                " ** \n" +
                "No response necessary...\n\n";

            emailMsg.insert(0, emailMsgEnv );
             boolean  isEmailOn = true;
    

            //----------------------------------------------------------------------
            // Remove any duplicate recipients
            //----------------------------------------------------------------------
            Vector cleanedEmailTos = new Vector();

            if( emailTos!=null && emailTos.size()>0 ) {
                for( int i=0; i<emailTos.size(); i++ ) {
                    if( !cleanedEmailTos.contains(emailTos.elementAt(i)) ) {
                        cleanedEmailTos.addElement(emailTos.elementAt(i));
                    }
                } // for
            } // if


            //----------------------------------------------------------------------
            // Get ready to send email....
            //----------------------------------------------------------------------
            //String host         = "marvin.cisco.com";
            String host         = "outbound.cisco.com";
            Properties props    = System.getProperties();
            props.put("mail.smtp.host",host);

            Session session = Session.getInstance(props,null);

            MimeMessage message = new MimeMessage(session);

            // Populate Subject:
            message.setSubject(emailSubject);

            // Populate From:
            InternetAddress addressFrom = new InternetAddress("SNOWBALL", "SNOWBALL Mailer");
            message.setFrom(addressFrom);

            // Populate To:
            InternetAddress[] addressTo = new InternetAddress[cleanedEmailTos.size()];

            if( cleanedEmailTos!=null ) {
                for (int i=0; i<cleanedEmailTos.size(); i++) {
                    String userId = (String) cleanedEmailTos.elementAt(i);
                    if( userId==null || userId.trim().equals("") ) {
                       addressTo[i] = new InternetAddress("snowball");
                    
                    } else {
                       addressTo[i] = new InternetAddress(userId);
                   }
                }
            } // if( cleanedEmailTos!=null )

            message.setRecipients(Message.RecipientType.TO, addressTo);
            if (addressCc != null && !suppressEmailCC)
            	message.setRecipients(Message.RecipientType.CC, addressCc);

            message.setContent(emailMsg.toString(), "text/html");

            // Send it

            Transport.send(message);

        } catch (UnsupportedEncodingException e) {
            throw new Exception ( THIS_METHOD + ". Exception. " + e );
        } catch (MessagingException e) {
            throw new Exception ( THIS_METHOD + ". Exception. " + e );
        }catch (Exception e) {
            throw new Exception ( THIS_METHOD + ". Exception. " + e );            
        }

    } // public static void sendMail

    private static void log(String s) {
        if (VERBOSE) System.out.println(s);
    }

} // public class Mail
