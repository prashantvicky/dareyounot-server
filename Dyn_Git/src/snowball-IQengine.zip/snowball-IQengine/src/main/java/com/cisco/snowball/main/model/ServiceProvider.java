/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.model;

import java.io.Serializable;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.json.simple.JSONObject;

import com.cisco.snowball.main.utilities.custom.postgress.JSONUserType;

@Entity
@Table(name="serviceprovider")
@TypeDefs({ @TypeDef(name = "TypeJsonObject", typeClass = JSONUserType.class) })
public class ServiceProvider implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This attribute maps to the column id in the SERVICE_PROVIDER table.
	 */
	@Id
	@SequenceGenerator(name = "SPseq", sequenceName = "sp_sequence", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SPseq")
	private long id;

	/**
	 * This attribute maps to the column name in the SERVICE_PROVIDER table.
	 */
	private String name;

	/**
	 * This attribute maps to the column status in the SERVICE_PROVIDER table.
	 */
	private String status;

	/**
	 * This attribute maps to the column revision in the SERVICE_PROVIDER table.
	 */
	@SequenceGenerator(name = "SPrevision", sequenceName = "revision_sp", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SPrevision")
	private int revision;

	/**
	 * This attribute maps to the column createdon in the SERVICE_PROVIDER
	 * table.
	 */
	private long createdOn;

	/**
	 * This attribute maps to the column createdby in the SERVICE_PROVIDER
	 * table.
	 */
	private String createdBy;

	/**
	 * This attribute maps to the column modifiedon in the SERVICE_PROVIDER
	 * table.
	 */
	private long modifiedOn;

	/**
	 * This attribute maps to the column modifiedby in the SERVICE_PROVIDER
	 * table.
	 */
	private String modifiedBy;

	/**
	 * This attribute maps to the column deleteAdmin in the SERVICE_PROVIDER table.
	 */
	private String deleteAdmin;

	/**
	 * This attribute maps to the column description in the SERVICE_PROVIDER
	 * table.
	 */
	private String description;

	/**
	 * This attribute maps to the column tags in the SERVICE_PROVIDER table.
	 */
	@Type(type = "TypeJsonObject")
	private JSONObject tags;

	/**
	 * This attribute maps to the column accountnumber in the SERVICE_PROVIDER
	 * table.
	 */
	private String accountNumber;

	/**
	 * This attribute maps to the column Head office address in the
	 * SERVICE_PROVIDER table.
	 */
	@Type(type = "TypeJsonObject")
	private JSONObject headOfficeAddress;

	/**
	 * This attribute maps to the column billingdetails in the SERVICE_PROVIDER
	 * table.
	 */
	@Type(type = "TypeJsonObject")
	private JSONObject billingDetails;

	/**
	 * This attribute maps to the column contactdetails in the SERVICE_PROVIDER
	 * table.
	 */
	@Type(type = "TypeJsonObject")
	private JSONObject contactDetails;

	/**
	 * This attribute maps to the column admindetails in the SERVICE_PROVIDER
	 * table.
	 */
	@Type(type = "TypeJsonObject")
	private JSONObject adminDetails;

	/**
	 * This attribute maps to the column connectiondetails in the
	 * SERVICE_PROVIDER table.
	 */
	@Type(type = "TypeJsonObject")
	private JSONObject connectionDetails;

	/**
	 * Method 'ServiceProvider'
	 * 
	 */
	public ServiceProvider() {
	}

	/**
	 * Method 'getId'
	 * @return
	 */
	public long getId() {
		return id;
	}

	/**
	 * Method 'setId'
	 * @param id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Method 'getName'
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method 'setName'
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Method 'getStatus'
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Method 'setStatus'
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Method 'getRevision'
	 * @return
	 */
	public int getRevision() {
		return revision;
	}

	/**
	 * Method 'setRevision'
	 * @param revision
	 */
	public void setRevision(int revision) {
		this.revision = revision;
	}

	/**
	 * Method 'getCreatedon'
	 * @return
	 */
	public long getCreatedOn() {
		return createdOn;
	}

	/**
	 * Method 'setCreatedon'
	 * @param createdon
	 */
	public void setCreatedOn(long createdon) {
		this.createdOn = createdon;
	}

	/**
	 * Method 'getCreatedby'
	 * @return
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Method 'setCreatedby'
	 * @param createdby
	 */
	public void setCreatedBy(String createdby) {
		this.createdBy = createdby;
	}

	/**
	 * Method 'getModifiedon'
	 * @return
	 */
	public long getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * Method 'setModifiedon'
	 * @param modifiedon
	 */
	public void setModifiedOn(long modifiedon) {
		this.modifiedOn = modifiedon;
	}

	/**
	 * Method 'getModifiedby'
	 * @return
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Method 'setModifiedby'
	 * @param modifiedby
	 */
	public void setModifiedBy(String modifiedby) {
		this.modifiedBy = modifiedby;
	}

	/**
	 * Method 'getDeleteadmin'
	 * @return
	 */
	public String getDeleteAdmin() {
		return deleteAdmin;
	}

	/**
	 * Method 'setHostname'
	 * @param hostname
	 */
	public void setDeleteAdmin(String deleteadmin) {
		this.deleteAdmin = deleteadmin;
	}

	/**
	 * Method 'getDescription'
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Method 'setDescription'
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Method 'getTags'
	 * @return
	 */
	public JSONObject getTags() {
		return tags;
	}

	/**
	 * Method 'setTags'
	 * @param tags
	 */
	public void setTags(JSONObject tags) {
		this.tags = tags;
	}
	/**
	 * Method 'getAccountnumber'
	 * @return
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Method 'setAccountnumber'
	 * @param accountnumber
	 */
	public void setAccountNumber(String accountnumber) {
		this.accountNumber = accountnumber;
	}

	/**
	 * Method 'getHeadofficeaddress'
	 * @return
	 */
	public JSONObject getHeadOfficeAddress() {
		return headOfficeAddress;
	}

	/**
	 * Method 'setHeadofficeaddress'
	 * @param headofficeaddress
	 */
	public void setHeadOfficeAddress(JSONObject headofficeaddress) {
		this.headOfficeAddress = headofficeaddress;
	}

	/**
	 * Method 'getBillingdetails'
	 * @return
	 */
	public JSONObject getBillingDetails() {
		return billingDetails;
	}

	/**
	 * Method 'setBillingdetails'
	 * @param billingdetails
	 */
	public void setBillingDetails(JSONObject billingdetails) {
		this.billingDetails = billingdetails;
	}

	/**
	 * Method 'getContactdetails'
	 * @return
	 */
	public JSONObject getContactDetails() {
		return contactDetails;
	}

	/**
	 * Method 'setContactdetails'
	 * @param contactdetails
	 */
	public void setContactDetails(JSONObject contactdetails) {
		this.contactDetails = contactdetails;
	}

	/**
	 * Method 'getAdmindetails'
	 * @return
	 */
	public JSONObject getAdminDetails() {
		return adminDetails;
	}

	/**
	 * Method 'setAdmindetails'
	 * @param admindetails
	 */
	public void setAdminDetails(JSONObject admindetails) {
		this.adminDetails = admindetails;
	}

	/**
	 * Method 'getConnectiondetails'
	 * @return
	 */
	public JSONObject getConnectionDetails() {
		return connectionDetails;
	}

	/**
	 * Method 'setConnectiondetails'
	 * @param connectiondetails
	 */
	public void setConnectionDetails(JSONObject connectiondetails) {
		this.connectionDetails = connectiondetails;
	}

	/**
	 * Method 'hashCode'
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result
				+ ((adminDetails == null) ? 0 : adminDetails.hashCode());
		result = prime * result
				+ ((billingDetails == null) ? 0 : billingDetails.hashCode());
		result = prime
				* result
				+ ((connectionDetails == null) ? 0 : connectionDetails
						.hashCode());
		result = prime * result
				+ ((contactDetails == null) ? 0 : contactDetails.hashCode());
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + (int) (createdOn ^ (createdOn >>> 32));
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime
				* result
				+ ((headOfficeAddress == null) ? 0 : headOfficeAddress
						.hashCode());
		result = prime * result
				+ ((deleteAdmin == null) ? 0 : deleteAdmin.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result + (int) (modifiedOn ^ (modifiedOn >>> 32));
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + revision;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((tags == null) ? 0 : tags.hashCode());
		return result;
	}

	/**
	 * Method 'equals'
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceProvider other = (ServiceProvider) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (adminDetails == null) {
			if (other.adminDetails != null)
				return false;
		} else if (!adminDetails.equals(other.adminDetails))
			return false;
		if (billingDetails == null) {
			if (other.billingDetails != null)
				return false;
		} else if (!billingDetails.equals(other.billingDetails))
			return false;
		if (connectionDetails == null) {
			if (other.connectionDetails != null)
				return false;
		} else if (!connectionDetails.equals(other.connectionDetails))
			return false;
		if (contactDetails == null) {
			if (other.contactDetails != null)
				return false;
		} else if (!contactDetails.equals(other.contactDetails))
			return false;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdOn != other.createdOn)
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (headOfficeAddress == null) {
			if (other.headOfficeAddress != null)
				return false;
		} else if (!headOfficeAddress.equals(other.headOfficeAddress))
			return false;
		if (deleteAdmin == null) {
			if (other.deleteAdmin != null)
				return false;
		} else if (!deleteAdmin.equals(other.deleteAdmin))
			return false;
		if (id != other.id)
			return false;
		if (modifiedBy == null) {
			if (other.modifiedBy != null)
				return false;
		} else if (!modifiedBy.equals(other.modifiedBy))
			return false;
		if (modifiedOn != other.modifiedOn)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (revision != other.revision)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (tags == null) {
			if (other.tags != null)
				return false;
		} else if (!tags.equals(other.tags))
			return false;
		return true;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString() {
		StringBuffer ret = new StringBuffer();
		ret.append("com.cisco.snowball.dto.ServiceProvider: ");
		ret.append("id=" + id);
		ret.append(", name=" + name);
		ret.append(", status=" + status);
		ret.append(", revision=" + revision);
		ret.append(", createdOn=" + createdOn);
		ret.append(", createdBy=" + createdBy);
		ret.append(", modifiedOn=" + modifiedOn);
		ret.append(", modifiedBy=" + modifiedBy);
		ret.append(", description=" + description);
		ret.append(", tags=" + tags);
		ret.append(", accountNumber=" + accountNumber);
		ret.append(", headOfficeAddress=" + headOfficeAddress);
		ret.append(", billingDetails=" + billingDetails);
		ret.append(", contactDetails=" + contactDetails);
		ret.append(", adminDetails=" + adminDetails);
		ret.append(", connectionDetails=" + connectionDetails);
		ret.append(", deleteAdmin=" + deleteAdmin);
		return ret.toString();
	}

	/**
	 * Cleans this service provider safe for updates.
	 */
	public ServiceProvider copyForAdd() {
		final ServiceProvider result = new ServiceProvider();
		
		result.name = this.name;
		result.status = this.status;
		result.description = this.description;
		result.tags = this.tags;
		result.accountNumber = this.accountNumber;
		result.headOfficeAddress = this.headOfficeAddress;
		result.billingDetails = this.billingDetails;
		result.contactDetails = this.contactDetails;
		result.adminDetails = this.adminDetails;
		result.connectionDetails = this.connectionDetails;

		return result;
	}
	
	/**
	 * Updates this instance with given instance.
	 */
	public void update(final ServiceProvider other) {
		this.name = other.name;
		this.status = other.status;
		this.description = other.description;
		this.tags = other.tags;
		this.accountNumber = other.accountNumber;
		this.headOfficeAddress = other.headOfficeAddress;
		this.billingDetails = other.billingDetails;
		this.contactDetails = other.contactDetails;
		this.adminDetails = other.adminDetails;
		this.connectionDetails = other.connectionDetails;
	}
}
