
/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.utilities;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.HandlerMapping;

import com.cisco.snowball.main.controller.MainController;
import com.cisco.snowball.main.model.User;
import com.cisco.snowball.main.service.IUserService;


@SuppressWarnings("deprecation")
@Component
public class CustomAuthenticationProvider implements AuthenticationProvider  {
 
	private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
	
	@Autowired
	IUserService userservice;
	
	@Autowired
	Encryptor enc;
	
    @Override
    public Authentication authenticate(Authentication authentication)
      throws AuthenticationException {
    	
        String name = authentication.getName();
        String apiKey = authentication.getCredentials().toString();
                           
        User user = userservice.findUserByUserName(name);
        
        System.out.println("Trying to authenticate apiKey " + apiKey + " for a user " + name);
        
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        
        //check if user is authorized for the requested resource
        String reqResource= getRequestedURL().replace("/v0", "");
        //check if user is authorized for execute Method
        String reqAction= attr.getRequest().getMethod();
        
        
        if (user!=null && apiKey.trim().equals(user.getApiKey().trim())) {
        	System.out.println("User " + user.getUsername() + " is authenticated");
        	
        	if(checkPermission(user.getRole(),reqResource,reqAction)){
                List<GrantedAuthority> grantedAuths = new ArrayList<>();
                GrantedAuthority ga = new GrantedAuthorityImpl("ROLE_USER");
                grantedAuths.add(ga);           
                attr.setAttribute("apiKey",user.getApiKey(),0);
                attr.setAttribute("username",user.getUsername(),0);
                return new UsernamePasswordAuthenticationToken(name, apiKey, grantedAuths);
        	}else{
        		attr.setAttribute("apiKey", "",0);
        		return null;
        	}
        	

        } else {
        	attr.setAttribute("apiKey", "",0);
        	logger.debug("User "  +  name + " - Unauthorized");
            return null;
        }
        
        
    }
 
 
    
    private boolean checkPermission(long role,String reqResource, String reqAction) {
		// TBD
		return true;
	}



	@Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
    
    
    
    
    private String getRequestedURL(){
    	 ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
         
         // trim request relative url
         String url = attr.getRequest().getRequestURI();
       //  if(url.startsWith("/") && url.length()>1)url=url.substring(1,url.length());
       //  url = url.substring(url.indexOf("/"),url.length());
        
         return url;
    }
    
}
