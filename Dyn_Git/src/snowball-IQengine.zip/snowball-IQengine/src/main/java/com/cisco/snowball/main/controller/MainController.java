
package com.cisco.snowball.main.controller;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.cisco.snowball.main.dao.IServiceProviderDao;
import com.cisco.snowball.main.model.Credential;
import com.cisco.snowball.main.model.Response2;
import com.cisco.snowball.main.model.User;
import com.cisco.snowball.main.service.IUserService;
import com.cisco.snowball.main.utilities.CustomAuthenticationProvider;
import com.cisco.snowball.main.utilities.Encryptor;
import com.cisco.snowball.main.utilities.Hasher;


@Controller
public class MainController {

	private static final Logger logger = Logger.getLogger(MainController.class);
	
	@Autowired
	CustomAuthenticationProvider custProvider;
	
	@Autowired
	IUserService iUser;
	
	@Autowired
	Encryptor enc;
	
	@Autowired
	IServiceProviderDao spdao;
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = {"/v0/login"}, method = RequestMethod.POST)
	public @ResponseBody Response2 login(@RequestBody Credential credential) {
		
		System.out.println("cheked in");
		Response2 response = new Response2();
		String userName= credential.getUsername();
		String passphrase = credential.getPassphrase();
		System.out.println(userName +" "+passphrase);
		if(credential.getUsername()==null || credential.getPassphrase()==null){
			response.setStatusCode(401);
			response.setStatusMsg("Unauthorized");			// instead it can be explicit 403 incorrect both user name or password are required.
			  //response.setStatusMsg("both user name or password are required");
			
		}else{
			User user = iUser.findUserByUserName(userName);			
			if (user==null){
				response.setStatusCode(401);
				//response.setStatusMsg("Unauthorized");    // instead it can be explicit 403 incorrect user name
				  response.setStatusMsg("incorrect user name");
				  
			}else {
				Hasher hash = new Hasher();
				if(user.getSalt() !=null /*&& hash.comparePassword(passphrase, user.getPassphrase(),user.getSalt())*/){
					response.setStatusCode(200);
					response.setStatusMsg("Ok");
					JSONObject result = new JSONObject();
					result.put("username", user.getUsername());
					result.put("name", user.getName());
					result.put("apiKey", user.getApiKey());
					result.put("loggedInBanner", "You must abide by the security procedures specified in the policy");
					result.put("permissions", null);		// TBD
					JSONArray resultArray = new JSONArray();
					resultArray.add(result);
					response.setResult(resultArray);
				}else{
					response.setStatusCode(403);
				//	response.setStatusMsg("Unauthorized");  	// instead it can be explicit 403 incorrect password
					response.setStatusMsg("incorrect password"); 
				}
				
			}
			
		}
		
		
		return response;
	}

	
	
		
	@RequestMapping("/testuser")				// temporary test method
	public @ResponseBody List<User> user() {
		User user = new User();
		Hasher hasher = new Hasher();
		user.setUsername("user2");
		user.setName("Misghna Gebrekirstos");
		user.setRole(1L);
		user.setPassphrase(hasher.getPBKDF2("123456"));			
		user.setApiKey(hasher.getApiKey("ROLE_USER"));
		iUser.create(user);
	    return iUser.findAll();
	}
	
	
	
	
}

