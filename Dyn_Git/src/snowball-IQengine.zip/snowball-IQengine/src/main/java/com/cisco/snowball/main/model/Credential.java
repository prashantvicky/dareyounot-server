package com.cisco.snowball.main.model;

public class Credential {

	
	private String username;
	private String passphrase;
	
	
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String userName) {
		this.username = userName;
	}
	
	
	public String getPassphrase() {
		return passphrase;
	}
	public void setPassphrase(String passphrase) {
		this.passphrase = passphrase;
	}

	
	
	
}
