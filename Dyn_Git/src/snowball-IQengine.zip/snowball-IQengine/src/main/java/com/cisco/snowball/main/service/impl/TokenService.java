/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cisco.snowball.main.dao.ITokenDao;
import com.cisco.snowball.main.dao.common.IOperations;
import com.cisco.snowball.main.model.Token;
import com.cisco.snowball.main.service.ITokenService;
import com.cisco.snowball.main.service.common.AbstractService;

@Service
public class TokenService extends AbstractService<Token> implements
		ITokenService {

	@Autowired
	private ITokenDao dao;

	public TokenService() {
		super();
	}

	public Token findTokenObject(final String tokenValue){
		return dao.findTokenObject(tokenValue);
	}
	
	@Override
	protected IOperations<Token> getDao() {
		return dao;
	}

}
