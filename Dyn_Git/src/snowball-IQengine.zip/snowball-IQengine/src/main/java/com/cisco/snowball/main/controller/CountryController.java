/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.JDBCException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cisco.snowball.main.model.Country;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.service.ICountryService;


@Controller
public class CountryController {

	protected static final Logger logger = LoggerFactory.getLogger(CountryController.class);
			

	@Autowired
	ICountryService cs;

	/**
	 * Fetches all the countries name
	 * 
	 * @return List<Countries>
	 */
	@RequestMapping(value = { "/v0/countries" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<String> getCountryNames() {
		Response<String>resp = new Response<String>();
		try {
			List<Country> countryList = cs.findAll();
			final String[] countries = new String[countryList.size()];
			for (int a=0;a<countries.length;a++) {
				countries[a] = countryList.get(a).getName();
			}
			resp.setResult(countries);
			resp.setStatusCode(HttpServletResponse.SC_OK);
			return resp;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			resp.setStatusMsg("Internal Server Error");
			resp.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return resp;
		} catch (HibernateException he) {
			logger.error("Hibernate Exception " + he.getMessage());
			resp.setStatusMsg("Internal Server Error");
			resp.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return resp;
		}
	}

	
}
