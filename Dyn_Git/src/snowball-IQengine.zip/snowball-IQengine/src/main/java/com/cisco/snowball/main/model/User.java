/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */
package com.cisco.snowball.main.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.json.simple.JSONObject;

import com.cisco.snowball.main.utilities.custom.postgress.JSONUserType;

@Entity
@Table(name="users")
@TypeDefs({ @TypeDef(name = "TypeJsonObject", typeClass = JSONUserType.class) })
public class User implements Serializable {

    @Id
	@SequenceGenerator(name = "Userseq", sequenceName = "user_sequence", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Userseq")
    private long id;
    
    private long spId;
    private String name;
    private String status;
    private Integer revision;
    private Long createdOn;
   	private String createdBy;
    private Long modifiedOn;
    private String modifiedBy;
    private String description;
    
    @Type(type = "TypeJsonObject")
    private JSONObject tags;
    private String username;
    private Long orgId;
    
    @Type(type = "TypeJsonObject")
    private JSONObject contactDetails;
    private String passphrase;
    
    @Type(type = "TypeJsonObject")
    private JSONObject auditHistory;
    
    private Long role;   
    private String apiKey;
    private String salt;
    private Long passphraseExpiration;
    
    
    
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	
	public long getSpId() {
		return spId;
	}
	public void setSpId(long spId) {
		this.spId = spId;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public Integer getRevision() {
		return revision;
	}
	public void setRevision(Integer revision) {
		this.revision = revision;
	}
	
	
	
	public Long getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Long createdOn) {
		this.createdOn = createdOn;
	}
	
	
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	
	
	public Long getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Long modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
	
	
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	public JSONObject getTags() {
		return tags;
	}
	public void setTags(JSONObject tags) {
		this.tags = tags;
	}
	
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	
	

	public JSONObject getAuditHistory() {
		return auditHistory;
	}
	public void setAuditHistory(JSONObject auditHistory) {
		this.auditHistory = auditHistory;
	}
	
	
	public Long getRole() {
		return role;
	}
	public void setRole(Long role) {
		this.role = role;
	}
	
	
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	
	
	public JSONObject getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(JSONObject contactDetails) {
		this.contactDetails = contactDetails;
	}
	
	
	public String getPassphrase() {
		return passphrase;
	}
	public void setPassphrase(String passphrase) {
		this.passphrase = passphrase;
	}	

	
	
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	
	
	public Long getPassphraseExpiration() {
		return passphraseExpiration;
	}
	public void setPassphraseExpiration(Long passphraseExpiration) {
		this.passphraseExpiration = passphraseExpiration;
	}
    


    
    


}
