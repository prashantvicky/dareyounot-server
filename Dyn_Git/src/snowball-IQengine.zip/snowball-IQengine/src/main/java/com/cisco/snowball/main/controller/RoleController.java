
/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.JDBCException;
import org.hibernate.MappingException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cisco.snowball.main.model.Count;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.Role;
import com.cisco.snowball.main.model.ServiceProvider;
import com.cisco.snowball.main.service.IRoleService;

@Controller
public class RoleController {

	protected static final Logger logger = LoggerFactory
			.getLogger(RoleController.class);

	@Autowired
	IRoleService objRole;

	/**
	 * Fetches all Role details
	 * 
	 * @param startingIndex
	 * @param count
	 * @return List<Role>
	 */
	@RequestMapping(value = { "/v0/role" }, method = RequestMethod.GET)
	public @ResponseBody
	List<Role> getAllRole(
			@RequestParam(value = "offset", required = false) Integer offset,
			@RequestParam(value = "limit", required = false) Integer limit) {
		try {
			if(offset == null){
				offset = 0;
			}
			if(limit == null){
				limit = 10;
			}
			List<Role> spList = objRole.findAll(offset, limit);
			return spList;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			List<Role> spList = new ArrayList<Role>();
			spList.add(sp);
			return spList;
		} catch (HibernateException he) {
			logger.error("Hibernate Exception " + he.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			List<Role> spList = new ArrayList<Role>();
			spList.add(sp);
			return spList;
		}
	}

	/**
	 * Fetches the details of a particular Role id
	 * 
	 * @param id
	 * @return Role
	 */

	@RequestMapping(value = { "/v0/role/{id}" }, method = RequestMethod.GET)
	public @ResponseBody
	Role getRoleById(@PathVariable(value = "id") long id) {
		try {
			return objRole.findOne(id);

		} catch (IndexOutOfBoundsException ife) {
			logger.error("No Service Provider details found for id : " + id
					+ " " + ife.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			return sp;
		} catch (ObjectNotFoundException onfe) {
			logger.error("No Service Provider details found for id : " + id
					+ " " + onfe.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			return sp;
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			return sp;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			return sp;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			Role sp = new Role();
			sp.setStatusMsg("failure");
			return sp;
		}
	}

	
         
	@RequestMapping(value = { "/v0/role/count" }, method = RequestMethod.GET)
	public @ResponseBody
	Count getRoleCount() {

		try {
			return objRole.getCount();
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Count cnt = new Count();
			//cnt.setStatusMsg("failure");
			return cnt;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			Count cnt = new Count();
			//cnt.setStatusMsg("failure");
			return cnt;
		}
	}

	/**
	 * Adds the Role details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/v0/role" }, method = RequestMethod.POST)
	public @ResponseBody
	Response createRole(@RequestBody(required = false) Role reqBody,
			HttpServletRequest req)  {
		try {
			final Role addrole = reqBody.copyForAdd();
			
			final long currentTime = System.currentTimeMillis();
			addrole.setcreatedBy(req.getUserPrincipal().getName());
			addrole.setmodifiedBy(req.getUserPrincipal().getName());
			addrole.setCreatedOn(currentTime);
			addrole.setModifiedOn(currentTime);
			return objRole.create(addrole);
			
			
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (ConstraintViolationException cve) {
			logger.error("Duplicate data " + cve.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Data Integrity violation " + dive.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		}
	}

	/**
	 * Updates the particular Role details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/v0/role/{id}" }, method = RequestMethod.PUT)
	public @ResponseBody
	Response<Role> updateRole(@PathVariable(value = "id") long id,
			@RequestBody(required = true) Role reqBody,
			HttpServletRequest request) {
		
//		final Role role = objRole.findOne(id);
//		if (role == null) {
//			logger.info("Service provider with id '" + id
//					+ "' not found, unable to update");
//			final Response<Role> res = new Response<Role>();
//			res.setStatusMsg("Not Found");
//			res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
//			return res;
//		}
//		
//		// check for invalid update
//		if ("Delete pending".equals(reqBody.getStatus())) {
//			logger.info("Service provider with id '" + id
//					+ "' unable to be updated, invalid status switch");
//			final Response<ServiceProvider> res = new Response<ServiceProvider>();
//			res.setStatusMsg("Bad Request");
//			res.setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
//			return res;
//		}
		
		
		
		try {
			
			reqBody.setmodifiedBy(request.getUserPrincipal().getName());
			reqBody.setModifiedOn(System.currentTimeMillis());
			return objRole.update(reqBody);
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Duplicate data " + dive.getMessage());
			Response res = new Response();
			res.setStatusMsg("duplicate");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		}

	}

	/**
	 * Deletes the Service Provider on basis of spId
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = { "/v0/role/{id}" }, method = RequestMethod.DELETE)
	public @ResponseBody
	Response<Role> deleteRole(@PathVariable(value = "id") long id
			
			) {
		
		
		
		try {
			
			return objRole.deleteById(id);
		} catch (IndexOutOfBoundsException ife) {
			logger.error("Cannot delete Service Provider with id : " + id + " "
					+ ife.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (ObjectNotFoundException onfe) {
			logger.error("Cannot delete Service Provider with id : " + id + " "
					+ onfe.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (MappingException me) {
			logger.error("Cannot map the field id" + me.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		}
	}

	

}
