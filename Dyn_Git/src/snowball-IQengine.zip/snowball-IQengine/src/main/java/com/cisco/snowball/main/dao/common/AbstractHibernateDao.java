/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.dao.common;

import java.io.Serializable;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.cisco.snowball.main.model.Count;
import com.cisco.snowball.main.model.Response;
import com.google.common.base.Preconditions;

@SuppressWarnings("unchecked")
public abstract class AbstractHibernateDao<T> implements IOperations<T> {
    private Class<T> clazz;

    @Autowired
    private SessionFactory sessionFactory;

    // API

    
    protected final void setClazz(final Class<T> clazzToSet) {
        clazz = Preconditions.checkNotNull(clazzToSet);
    }

    protected String getFindAllOrderByParameter() {
    	return "name";
    }
    
    @Override
    public final T findOne(final long id) throws HibernateException{
    	
        return (T) getCurrentSession().get(clazz, id);
    }
    
    
    
    @Override
    public final List<T> findAll(final int offset, final int limit) throws HibernateException {
        return  getCurrentSession().createQuery("from " + clazz.getName() + " order by " + 
        		getFindAllOrderByParameter())
        		.setFirstResult(offset)
        		.setMaxResults(limit)
        		.list();
    }
    
    
    
    @Override
    public Count getCount() throws HibernateException{
    		Count cnt = new Count();
    		cnt.setCount(((Long) sessionFactory.getCurrentSession()
    				.createQuery("select count(*) from " + clazz.getName())
    				.uniqueResult()).intValue());
    	return cnt;
    }
    
    
    
    @Override
    public final List<T> findAll() throws HibernateException{
        return getCurrentSession().createQuery("from " + clazz.getName()).list();
    }
    
    

    @Override
    public final Response<T> create(final T entity) throws HibernateException {
        Preconditions.checkNotNull(entity);
        final Serializable id = getCurrentSession().save(entity);
        Response<T> res = new Response<T>();
        res.setResult((T) getCurrentSession().get(clazz, id));
        return res;
    }

    
    
    
    @Override
    public final Response<T> update(final T entity) throws HibernateException{
        Preconditions.checkNotNull(entity);
        T result = (T)getCurrentSession().merge(entity);
        Response<T> res = new Response<T>();
        res.setResult(result);
        return res;
    }

 
    
    @Override
    public final Response<T> delete(final T entity) throws HibernateException{
        Preconditions.checkNotNull(entity);
        getCurrentSession().delete(entity);
        Response<T> res = new Response<T>();
        return res;
    }
  
    
    
    protected final Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

}