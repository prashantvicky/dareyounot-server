/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cisco.snowball.main.dao.IFriendInfoDao;
import com.cisco.snowball.main.dao.common.IOperations;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.FriendInfo;
import com.cisco.snowball.main.service.IFriendInfoService;
import com.cisco.snowball.main.service.common.AbstractService;

@Service
public class FriendInfoService extends AbstractService<FriendInfo>
		implements IFriendInfoService {

	
	@Autowired
	private IFriendInfoDao dao;

	public FriendInfoService() {
		super();
	}

	
	
	public Response deleteById(long id, String hostName){
		
		return dao.deleteById(id,hostName);
	}

	
	
	@Override
	protected IOperations<FriendInfo> getDao() {
		return dao;
	}

}
