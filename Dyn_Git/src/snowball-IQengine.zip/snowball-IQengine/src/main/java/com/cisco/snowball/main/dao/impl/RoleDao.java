/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.dao.impl;

import javax.persistence.Column;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;

import com.cisco.snowball.main.dao.IRoleDao;
import com.cisco.snowball.main.dao.common.AbstractHibernateDao;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.Role;
import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;

@Repository
public class RoleDao extends AbstractHibernateDao<Role> implements IRoleDao {

	@Id
	@Column(name = "id")
	@org.hibernate.annotations.Type(type = "org.hibernate.type.PostgresUUIDType")
	java.util.UUID ui;

	@Autowired
	private SessionFactory sessionFactory;

	public RoleDao() {
		super();

		setClazz(Role.class);
	}
        public Response deleteById(long id)
			throws HibernateException { 
		
		Response res = new Response();
		
			res = delete(findOne(id));
		

		return res;
	}

}
