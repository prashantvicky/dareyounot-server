package com.cisco.snowball.main.utilities;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Date;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import org.springframework.stereotype.Component;


@Component
public class Hasher {

	final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();
	
	public String getApiKey(String role){
		
		StringBuffer sb =null;
			SecureRandom random = new SecureRandom();
			String clearText = role + (new BigInteger(130, random)).toString(32) + (new Date()).getTime();
				
			try{
		    MessageDigest md = MessageDigest.getInstance("SHA-256");
		    md.update(clearText.getBytes());
		
		    byte byteData[] = md.digest();
		
		     sb = new StringBuffer();
		    for (int i = 0; i < byteData.length; i++) {
		     sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
		    }
			
		    System.out.println(sb.toString());
			}catch (Exception e){e.printStackTrace();}
		
		return sb.toString();
	
	}
	
	
	
	public String getPBKDF2(String clearText, String salt){
	
		SecureRandom rand = new SecureRandom();		
		byte[] result =pbkdf2(clearText.toCharArray(),salt.getBytes(),1000,128);   // 16 is returning very small length result ... to be checked!
		
		return bytesToHex(result);
	}
	
	
	public String getPBKDF2(String clearText){
		
		SecureRandom rand = new SecureRandom();		
		String salt = (new BigInteger(64, rand)).toString();
		byte[] result =pbkdf2(clearText.toCharArray(),salt.getBytes(),1000,128);   // 16 is returning very small length result ... to be checked!
		
		return bytesToHex(result);
	}
	
	
	private byte[] pbkdf2(final char[] password, final byte[] salt,
            final int iterationCount, final int keyLength) {
		
		byte[] hashed =null;
		  try {
			  KeySpec spec = new PBEKeySpec(password, salt, iterationCount, keyLength);
			  SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			 return f.generateSecret(spec).getEncoded();
		  } catch (Exception e) {
		     e.printStackTrace();
		  }
		  
		  return hashed;
	}

	
	
	
	private String bytesToHex(byte[] bytes) {
	    char[] hexChars = new char[bytes.length * 2];
	    for ( int j = 0; j < bytes.length; j++ ) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}
	
	
	public boolean comparePassword(String clearText, String hashed, String salt){
		String hashPassword = getPBKDF2(clearText,salt).trim();
		System.out.println("from user " + hashPassword + " from db " + hashed.trim());
		return hashPassword.equals(hashed.trim());
		
	}
	
	
}
