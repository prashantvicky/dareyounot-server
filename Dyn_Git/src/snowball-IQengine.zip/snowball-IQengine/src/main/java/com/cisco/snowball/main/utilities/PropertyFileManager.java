
/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import sun.awt.AppContext;

@Component
public class PropertyFileManager {
	
	@Autowired
	ServletContext servletContext;
	 
	 public JSONArray getJSONData2(String JSONName){
		 Properties properties = new Properties();
		 try{
			 properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("dataSetting.properties"));	
			 JSONArray jArray = new JSONArray(properties.get(JSONName + ".properties").toString());
			 return jArray;
		 }catch (Exception e){e.printStackTrace();}		 
		 return null;
	 }

	
	 
	 public JSONArray getJSONData(String JSONName){
		 Properties properties=null;
		 try{
		 if (servletContext.getAttribute("propFile")==null) {
			 properties = new Properties();
			 properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("dataSetting.properties"));
			 servletContext.setAttribute("propFile",properties);
		 }
		 else properties=(Properties)servletContext.getAttribute("propFile");			 	
			 JSONArray jArray = new JSONArray(properties.get(JSONName + ".properties").toString());
			 return jArray;
		 }catch (Exception e){e.printStackTrace();}		 
		 		 
		 return null;
	 }
	 
	 
	 public String updateProperties(String JSONName, String JsonData,HttpServletRequest req){
		 Properties prop = new Properties();
			OutputStream output = null;
			
			try {
				prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("dataSetting.properties"));
				// set the properties value
				JsonData = JsonData.substring(8, JsonData.length()-1); // trim the extra shell "data"
				JsonData = JsonData.replace("\\", "");
				prop.setProperty(JSONName + ".properties", JsonData);
				String path = servletContext.getRealPath("\\WEB-INF\\classes\\dataSetting.properties");			
				output= new FileOutputStream(path);
				// save properties to project root folder
				prop.store(output, null);
				servletContext.setAttribute("propFile",prop);
				
			} catch (IOException io) {
				io.printStackTrace();
				return "error";
			} finally {
				if (output != null) {
					try {
						output.close();
					} catch (IOException e) {
						e.printStackTrace();
						return "error";
					}
				}
		 
			}
			return "success";
		  }
	 
		 
	 
	 
}
