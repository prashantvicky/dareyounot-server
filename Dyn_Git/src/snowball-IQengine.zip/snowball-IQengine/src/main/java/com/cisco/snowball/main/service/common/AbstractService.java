/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.service.common;

import java.io.Serializable;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.transaction.annotation.Transactional;

import com.cisco.snowball.main.dao.common.IOperations;
import com.cisco.snowball.main.model.Count;
import com.cisco.snowball.main.model.Response;

@Transactional
public abstract class AbstractService<T extends Serializable> implements IOperations<T> {

    @Override
    public T findOne(final long id) throws HibernateException{
        return getDao().findOne(id);
    }
    
    @Override
    public List<T> findAll(final int offset, final int limit) throws HibernateException{
        return getDao().findAll(offset, limit);
    }
    
    @Override
    public Count getCount() throws HibernateException{
        return getDao().getCount();
    }
    
    
    @Override
    public List<T> findAll() throws HibernateException{
        return getDao().findAll();
    }

    @Override
    public Response create(final T entity) throws HibernateException{
        return getDao().create(entity);
    }

    @Override
    public Response update(final T entity) throws HibernateException{
        return getDao().update(entity);
    }

    @Override
    public Response delete(final T entity) throws HibernateException{
       return getDao().delete(entity);
    }

    
    protected abstract IOperations<T> getDao();

}
