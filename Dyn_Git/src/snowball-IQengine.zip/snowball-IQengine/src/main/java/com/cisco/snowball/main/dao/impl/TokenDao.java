/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.dao.impl;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cisco.snowball.main.dao.ITokenDao;
import com.cisco.snowball.main.dao.common.AbstractHibernateDao;
import com.cisco.snowball.main.model.Token;


@Repository
public class TokenDao extends AbstractHibernateDao<Token> implements ITokenDao {


	@Autowired
    private SessionFactory sessionFactory;
    public TokenDao() {
        super();

        setClazz(Token.class);
    }
    
  public Token findTokenObject(final String tokenValue){
	  	
	  	return (Token)getCurrentSession().createQuery("from Token where token='" +tokenValue  + "'").list().get(0);
    }
    

}
