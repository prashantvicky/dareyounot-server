/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cisco.snowball.main.model.Response2;
 
@Controller
@RequestMapping("/errors")
public class ExceptionController {
 
	
 	@ResponseStatus(value=HttpStatus.UNAUTHORIZED)
    @RequestMapping("unauthorised")
    public @ResponseBody Response2 unAuthorised(HttpServletRequest request) throws Exception {
 		Response2 response = new Response2();
 		response.setStatusCode(401);
 		response.setStatusMsg("Unauthorized");
    	return response;
    }
	   
 	
    @ResponseStatus(value=HttpStatus.NOT_FOUND)
    @RequestMapping("resourcenotfound")
    @ResponseBody
    public Response2 resourceNotFound(HttpServletRequest request) throws Exception {
    	Response2 response = new Response2();
 		response.setStatusCode(404);
 		response.setStatusMsg("Resource Not Found");
    	return response;
    }

   
     
	@RequestMapping("/403")
	public @ResponseBody Response2 accessDenied() {
		Response2 response = new Response2();
 		response.setStatusCode(403);
 		response.setStatusMsg("Access Denied");
    	return response;
	}
	
	@RequestMapping("/badRequest")
	public @ResponseBody Response2  BadRequest() {
		Response2 response = new Response2();
 		response.setStatusCode(400);
 		response.setStatusMsg("Bad Request");
    	return response;
	}
	
	@RequestMapping("/InternalServerError")
	public @ResponseBody Response2  InternalServerError() {
		Response2 response = new Response2();
 		response.setStatusCode(500);
 		response.setStatusMsg("Internal Server Error");
    	return response;
	}
	
	@RequestMapping("/Serviceunavailable")
	public @ResponseBody Response2  ServiceUnavailable() {
		Response2 response = new Response2();
 		response.setStatusCode(503);
 		response.setStatusMsg("Service Unavailable");
    	return response;
	}
	

    
}
