
/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.controller;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.JDBCException;
import org.hibernate.MappingException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.exception.ConstraintViolationException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cisco.snowball.main.model.Count;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.Register;
import com.cisco.snowball.main.service.IRegisterService;

@Controller
public class RegisterController {

	protected static final Logger logger = LoggerFactory
			.getLogger(RegisterController.class);

	@Autowired
	IRegisterService objRegister;

	/**
	 * Fetches all Register details
	 * 
	 * @param startingIndex
	 * @param count
	 * @return List<Register>
	 */
	@RequestMapping(value = { "/sb/main/v0/register" }, method = RequestMethod.GET)
	public @ResponseBody
	List<Register> getAllRegister(
			@RequestParam(value = "offset", required = false) Integer offset,
			@RequestParam(value = "limit", required = false) Integer limit) {
		try {
			if(offset == null){
				offset = 0;
			}
			if(limit == null){
				limit = 10;
			}
			List<Register> spList = objRegister.findAll(offset, limit);
			return spList;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			List<Register> spList = new ArrayList<Register>();
			spList.add(sp);
			return spList;
		} catch (HibernateException he) {
			logger.error("Hibernate Exception " + he.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			List<Register> spList = new ArrayList<Register>();
			spList.add(sp);
			return spList;
		}
	}

	/**
	 * Fetches the details of a particular SP id
	 * 
	 * @param id
	 * @return Register
	 */

	@RequestMapping(value = { "/sb/main/v0/register/{id}" }, method = RequestMethod.GET)
	public @ResponseBody
	Register getSpById(@PathVariable(value = "id") long id) {
		try {
			return objRegister.findOne(id);

		} catch (IndexOutOfBoundsException ife) {
			logger.error("No Service Provider details found for id : " + id
					+ " " + ife.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			return sp;
		} catch (ObjectNotFoundException onfe) {
			logger.error("No Service Provider details found for id : " + id
					+ " " + onfe.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			return sp;
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			return sp;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			return sp;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			Register sp = new Register();
			sp.setStatusMsg("failure");
			return sp;
		}
	}

	/**
	 * Fetches the total SP count
	 * 
	 * @return count
	 */
	@RequestMapping(value = { "/sb/main/v0/register/count" }, method = RequestMethod.GET)
	public @ResponseBody
	Count getSpCount() {

		try {
			return objRegister.getCount();
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Count cnt = new Count();
			//cnt.setStatusMsg("failure");
			return cnt;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			Count cnt = new Count();
			//cnt.setStatusMsg("failure");
			return cnt;
		}
	}

	/**
	 * Adds the SP details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/sb/main/v0/register" }, method = RequestMethod.POST)
	public @ResponseBody
	Response createSP(@RequestBody(required = true) Register reqBody, BindingResult result) {
		try {
			return objRegister.create(reqBody);
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (ConstraintViolationException cve) {
			logger.error("Duplicate data " + cve.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Data Integrity violation " + dive.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		}
	}

	/**
	 * Updates the particular SP details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/sb/main/v0/register" }, method = RequestMethod.PUT)
	public @ResponseBody
	Response updateSP(@RequestBody(required = true) Register reqBody) {
		try {
			return objRegister.update(reqBody);
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Duplicate data " + dive.getMessage());
			Response res = new Response();
			res.setStatusMsg("duplicate");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		}

	}

	/**
	 * Deletes the Service Provider on basis of spId
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = { "/sb/main/v0/register" }, method = RequestMethod.DELETE)
	public @ResponseBody
	Response deleteSP(@RequestParam(value = "id", required = true) long id,
			@RequestParam(value = "host", required = true) String host) {
		try {
			return objRegister.deleteById(id, host);
		} catch (IndexOutOfBoundsException ife) {
			logger.error("Cannot delete Service Provider with id : " + id + " "
					+ ife.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (ObjectNotFoundException onfe) {
			logger.error("Cannot delete Service Provider with id : " + id + " "
					+ onfe.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (MappingException me) {
			logger.error("Cannot map the field id" + me.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			Response res = new Response();
			res.setStatusMsg("failure");
			return res;
		}
	}

	

}
