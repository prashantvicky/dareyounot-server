/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Token implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public long getTtl() {
		return ttl;
	}


	public void setTtl(long ttl) {
		this.ttl = ttl;
	}


	@Id
	//@GeneratedValue
	private long id;
    private String token;
    private long ttl;
    private String userName;


    public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}



	@Override
    public String toString() {
		StringBuffer ret = new StringBuffer();
		ret.append("com.cisco.snowball.dto.Token: ");
		ret.append("id=" + id);
		ret.append(", token=" + token);
		ret.append(", ttl=" + ttl);
		ret.append(", username=" + userName);
		return ret.toString();
    }

}
