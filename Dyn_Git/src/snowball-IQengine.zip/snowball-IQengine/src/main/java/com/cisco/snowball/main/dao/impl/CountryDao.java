/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.dao.impl;
import org.springframework.stereotype.Repository;
import com.cisco.snowball.main.dao.ICountryDao;
import com.cisco.snowball.main.dao.common.AbstractHibernateDao;
import com.cisco.snowball.main.model.Country;

@Repository
public class CountryDao extends AbstractHibernateDao<Country> implements ICountryDao {


    public CountryDao() {
        super();

        setClazz(Country.class);
    }

/**
 * Fetches the state names on the basis of country name
 */
    public Country findStatesByCountry(final String countryName){
	  	
	  	return (Country)getCurrentSession().createQuery("from Country where name='" + countryName  + "'").list().get(0);
    }

}
