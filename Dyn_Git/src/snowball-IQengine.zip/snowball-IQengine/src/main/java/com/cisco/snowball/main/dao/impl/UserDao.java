/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.dao.impl;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cisco.snowball.main.dao.IUserDao;
import com.cisco.snowball.main.dao.common.AbstractHibernateDao;
import com.cisco.snowball.main.model.User;
import com.google.common.base.Preconditions;

@Repository
public class UserDao extends AbstractHibernateDao<User> implements IUserDao {
	
    @Autowired
    private SessionFactory sessionFactory;

    public UserDao() {
        super();

        setClazz(User.class);
    }

    public User findUserByUserName(String userName){
	   	List user = sessionFactory.getCurrentSession().createQuery("from User where username='" + userName  + "'").list();
	   	if(user.size()>0)return (User)user.get(0);
	   	else return null;
    }

	public User addUser(User entity)
			throws HibernateException {
		Preconditions.checkNotNull(entity);
		return (User) getCurrentSession().merge(entity);
	}

	public final User updateById(final long id,
			final User entity) throws HibernateException {
		Preconditions.checkNotNull(id, entity);
		if(findOne(id) != null){
			entity.setId(id);
			return (User) getCurrentSession().merge(Long.toString(id), entity);
		}else{
			return null;
		}
	}
   
}
