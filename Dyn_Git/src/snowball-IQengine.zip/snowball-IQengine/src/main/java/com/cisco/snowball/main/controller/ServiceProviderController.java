/*
 * This computer program is the confidential information and proprietary trade
 * secret of Cisco Systems, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and Cisco Systems,
 * Inc., and receipt or possession does not convey any rights to divulge,
 * reproduce, or allow others to use this program without specific written
 * authorization of Cisco Systems, Inc.
 *
 * Copyright 2014 Cisco Systems, Inc. All rights reserved.
 */

package com.cisco.snowball.main.controller;

import static java.util.concurrent.TimeUnit.MILLISECONDS;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.List;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.JDBCException;
import org.hibernate.MappingException;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cisco.snowball.main.config.core.Mail;
import com.cisco.snowball.main.model.Count;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.ServiceProvider;
import com.cisco.snowball.main.model.Token;
import com.cisco.snowball.main.model.User;
import com.cisco.snowball.main.service.IServiceProviderService;
import com.cisco.snowball.main.service.ITokenService;
import com.cisco.snowball.main.service.IUserService;

@Controller
public class ServiceProviderController {

	protected static final Logger logger = LoggerFactory
			.getLogger(ServiceProviderController.class);

	@Autowired
	IServiceProviderService sps;
	@Autowired
	ITokenService tok;
	@Autowired
	IUserService user;

	/**
	 * Fetches all ServiceProvider details
	 * 
	 * @param startingIndex
	 * @param count
	 * @return List<ServiceProvider>
	 */
	@RequestMapping(value = { "/v0/sps" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<ServiceProvider> getAllSps(
			@RequestParam(value = "offset", required = false) Integer offset,
			@RequestParam(value = "limit", required = false) Integer limit) {
		
		if (offset == null) {
			offset = 0;
		}
		if (limit == null) {
			limit = 10;
		}
		final List<ServiceProvider> spList = sps.findAll(offset, limit);
		final Response<ServiceProvider> res = new Response<ServiceProvider>();
		res.setResult((spList.toArray(new ServiceProvider[] {})));
		res.setStatusCode(HttpServletResponse.SC_OK);
		return res;
	}

	/**
	 * Fetches the details of a particular SP id
	 * 
	 * @param id
	 * @return ServiceProvider
	 */

	@RequestMapping(value = { "/v0/sps/{id}" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<ServiceProvider> getSpById(@PathVariable(value = "id") long id) {
		Response<ServiceProvider> res = new Response<ServiceProvider>();
		ServiceProvider sp = sps.findOne(id);
		if (sp == null) {
			logger.info("Service provider with id '" + id
					+ "' not found, unable to return");
			res.setStatusMsg("Not Found");
			res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
			return res;
		}
		res.setResult(new ServiceProvider[] { sp });
		res.setStatusMsg("OK");
		res.setStatusCode(HttpServletResponse.SC_OK);
		return res;
	}

	/**
	 * Fetches the total SP count
	 * 
	 * @return count
	 */
	@RequestMapping(value = { "/v0/sps/count" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<Count> getSpCount() {
		Response<Count> res = new Response<Count>();
		try {
			Count count = sps.getCount();
			res.setResult(new Count[] { count });
			res.setStatusCode(HttpServletResponse.SC_OK);
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		}
	}

	/**
	 * Adds the SP details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/v0/sps" }, method = RequestMethod.POST)
	public @ResponseBody
	Response<ServiceProvider> createSP(
			@RequestBody(required = false) ServiceProvider reqBody,
			HttpServletRequest req) {

		// TODO: Misghna, we need to add the admin during this and if that fails then we can't add the SP
		// then we need to send the email to the admin (if that fails we are still successful)
		final ServiceProvider addServiceProvider = reqBody.copyForAdd();
		
		final long currentTime = System.currentTimeMillis();
		addServiceProvider.setCreatedBy(req.getUserPrincipal().getName());
		addServiceProvider.setModifiedBy(req.getUserPrincipal().getName());
		addServiceProvider.setCreatedOn(currentTime);
		addServiceProvider.setModifiedOn(currentTime);
		return sps.create(addServiceProvider);
	}

	/**
	 * Updates the particular SP details
	 * o
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/v0/sps/{id}" }, method = RequestMethod.PUT)
	public @ResponseBody
	Response<ServiceProvider> updateSP(@PathVariable(value = "id") long id,
			@RequestBody(required = true) ServiceProvider reqBody,
			HttpServletRequest request) {
		
		final ServiceProvider localSp = sps.findOne(id);
		if (localSp == null) {
			logger.info("Service provider with id '" + id
					+ "' not found, unable to update");
			final Response<ServiceProvider> res = new Response<ServiceProvider>();
			res.setStatusMsg("Not Found");
			res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
			return res;
		}
		
		// check for invalid update
		if ("Delete pending".equals(reqBody.getStatus()) && localSp.getDeleteAdmin() == null) {
			logger.info("Service provider with id '" + id
					+ "' unable to be updated, invalid status switch");
			final Response<ServiceProvider> res = new Response<ServiceProvider>();
			res.setStatusMsg("Bad Request");
			res.setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
			return res;
		}
		
		localSp.update(reqBody);
		
		// if we have switch to active
		if (!localSp.getStatus().equals("Delete pending")) {
			localSp.setDeleteAdmin(null);
		}
		
		localSp.setModifiedBy(request.getUserPrincipal().getName());
		localSp.setModifiedOn(System.currentTimeMillis());
		return sps.update(localSp);
	}

	/**
	 * Deletes the Service Provider on basis of spId
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = { "/v0/sps/{id}" }, method = RequestMethod.DELETE)
	public @ResponseBody
	Response<ServiceProvider> deleteSP(
			@PathVariable(value = "id") long id,
			HttpServletRequest request) {
		
		final ServiceProvider localSp = sps.findOne(id);
		if (localSp == null) {
			logger.info("Service provider with id '" + id
					+ "' not found, unable to delete");
			final Response<ServiceProvider> res = new Response<ServiceProvider>();
			res.setStatusMsg("Not Found");
			res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
			return res;
		}
		
		// initial stage of delete
		if (localSp.getDeleteAdmin() == null) {
			
			localSp.setModifiedBy(request.getUserPrincipal().getName());
			localSp.setModifiedOn(System.currentTimeMillis());
			localSp.setDeleteAdmin(request.getUserPrincipal().getName());
			localSp.setStatus("Delete pending");
			return sps.update(localSp);
		}
		
		// need different user to complete delete
		if (localSp.getDeleteAdmin().equals(request.getUserPrincipal().getName())) {
			logger.info("Service provider with id '" + id
					+ "' unable to be deleted, different admin must perform operation");
			final Response<ServiceProvider> res = new Response<ServiceProvider>();
			res.setStatusMsg("Bad Request");
			res.setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
			return res;
		}
		
		// TODO: Misghna, we should delete the user as well
		
		// otherwise we can delete
		return sps.delete(localSp);
	}

	
	
	// TODO: Misghna, check the documentation (that I will send), the URL should be /v0/sp/{id}/resetPassphrase
	// also, we don't need a username param, just reset the admin user
	@RequestMapping(method = RequestMethod.POST, value = "/v0/sps/rstpwlink/{id}")
	public @ResponseBody
	Response<ServiceProvider> sendLink(@PathVariable(value = "id") long id,
			@RequestParam(value = "username", required = true) String emailId) {
		Response<ServiceProvider> res = new Response<ServiceProvider>();
		
		
		
		try {
			
			sendPassphraseResetLink(id, emailId);			// to be checked

			res.setResult(new ServiceProvider[] {});
			res.setStatusCode(HttpServletResponse.SC_OK);
			return res;

		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (ConstraintViolationException cve) {
			logger.error("Duplicate data " + cve.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Data Integrity violation " + dive.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (Exception e) {
			logger.error("Mail Exception " + e.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		}
	}

	
	
	
	
	private void sendPassphraseResetLink(long id, String emailId)
			throws Exception {
		SecureRandom random = new SecureRandom();
		String auth_token = new BigInteger(256, random).toString(32);
		Token t = new Token();
		long ttl = System.currentTimeMillis();

		t.setId(id);
		t.setToken(auth_token);
		t.setTtl(ttl);
		t.setUserName(emailId);

		Vector ids = new Vector();
		ids.add(emailId);
		StringBuffer sbf = new StringBuffer("Email Message  ");

		sbf.append("Reset Password Link: "
				+ "<a href='http://localhost:8080/snowball/v0/sps/" + id
				+ "/resetPassphrase?authtoken=" + auth_token + "&username="
				+ emailId + "'>Token</a>"
				+ ". This Token is valid for 24 hrs ");
		String subject = "Test message";

		Mail.sendMail("Reset Password Link Notification", ids, sbf);
		tok.create(t);
	}

	
	
	
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/v0/sps/{id}/resetPassphrase")
	public @ResponseBody
	Response<ServiceProvider> setPassword(
			@PathVariable(value = "id") String id,
			@RequestParam(value = "authtoken", required = true) String token,
			@RequestParam(value = "username", required = true) String emailId,
			@RequestParam(value = "password", required = true) String pwd) {
		Response<ServiceProvider> res = new Response<ServiceProvider>();
		try {
			Token tk = tok.findTokenObject(token);
			long ttl = System.currentTimeMillis();
			long ttl1 = tk.getTtl();

			int hrs = (int) (MILLISECONDS.toHours(ttl - ttl1) % 24);

			System.out.println(hrs);
			if (hrs > 24) {
				res.setStatusMsg("Internal Server Error");
				res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				return res;
			}

			User modifyUser = user.findUserByUserName(emailId);
			modifyUser.setPassphrase(pwd);
			user.update(modifyUser);

			res.setResult(new ServiceProvider[] {});
			res.setStatusCode(HttpServletResponse.SC_OK);
			return res;
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (ConstraintViolationException cve) {
			logger.error("Duplicate data " + cve.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Data Integrity violation " + dive.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		}
	}

}
