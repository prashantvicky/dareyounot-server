package com.cisco.snowball.main.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.JDBCException;
import org.hibernate.MappingException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.exception.ConstraintViolationException;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cisco.snowball.main.model.Count;
import com.cisco.snowball.main.model.Response;
import com.cisco.snowball.main.model.ServiceProvider;
import com.cisco.snowball.main.model.User;
import com.cisco.snowball.main.service.IUserService;

@Controller
public class UserController {

	protected static final Logger logger = LoggerFactory
			.getLogger(UserController.class);

	@Autowired
	IUserService user;

	/**
	 * Fetches all User details
	 * 
	 * @param offset
	 * @param limit
	 * @return List<User>
	 */
	@RequestMapping(value = { "/v0/users" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<User> getAllSps(
			@RequestParam(value = "offset", required = false) Integer offset,
			@RequestParam(value = "limit", required = false) Integer limit) {
		Response<User> res = new Response<User>();
		try {
			if (offset == null) {
				offset = 0;
			}
			if (limit == null) {
				Count count = user.getCount();
				long cnt = count.getCount();
				if (cnt >= 10) {
					limit = 10;
				} else {
					limit = (int) cnt;
				}
			}
			List<User> userList = user.findAll(offset, limit);
			if (userList != null && userList.size() > 0) {
				res.setResult((userList.toArray(new User[] {})));
				res.setStatusCode(HttpServletResponse.SC_OK);
			} else {
				res.setResult(null);
				res.setStatusMsg("Not Found");
				res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
			}

			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			res.setStatusMsg("Internal Server Error");
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Exception " + he.getMessage());
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			res.setStatusMsg("Internal Server Error");
			return res;
		}
	}

	/**
	 * Fetches the details of a particular User id
	 * 
	 * @param id
	 * @return User
	 */

	@RequestMapping(value = { "/v0/users/{id}" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<User> getSpById(@PathVariable(value = "id") long id) {
		Response<User> res = new Response<User>();
		
			User userDetails = user.findOne(id);
			if (userDetails != null) {
				res.setResult(new User[] { userDetails });
				res.setStatusCode(HttpServletResponse.SC_OK);
			}else{
				res.setResult(null);
				res.setStatusMsg("Not Found");
				res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
			}
			return res;
		
	}
	
	/**
	 * Fetches the total Users count
	 * 
	 * @return count
	 */
	@RequestMapping(value = { "/v0/users/count" }, method = RequestMethod.GET)
	public @ResponseBody
	Response<Count> getSpCount() {
		Response<Count> res = new Response<Count>();
		try {
			Count count = user.getCount();
			res.setResult(new Count[] { count });
			res.setStatusCode(HttpServletResponse.SC_OK);
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate exception" + he.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		}
	}
	
	/**
	 * Adds the User details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/v0/users" }, method = RequestMethod.POST)
	public @ResponseBody
	Response<User> createSP(
			@RequestBody(required = false) User reqBody,
			HttpServletRequest req) {
		
		//JSONObject spJo = parseToJson(req);		// Custom mapping TBD
		
		
		Response<User> res = new Response<User>();
		try {
			long currentTime = System.currentTimeMillis();
			reqBody.setCreatedBy(req.getUserPrincipal().getName());
			reqBody.setModifiedBy(req.getUserPrincipal().getName());
			reqBody.setCreatedOn(currentTime);
			reqBody.setModifiedOn(currentTime);
			res.setResult(new User[] { user.addUser(reqBody) });
			res.setStatusCode(HttpServletResponse.SC_OK);
			return res;
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (ConstraintViolationException cve) {
			logger.error("Duplicate data " + cve.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Data Integrity violation " + dive.getMessage());
			res.setStatusMsg("Bad Request");
			res.setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		}
	}
	
	/**
	 * Updates the particular User details
	 * 
	 * @param reqBody
	 * @return success or failure code
	 */
	@RequestMapping(value = { "/v0/users/{id}" }, method = RequestMethod.PUT)
	public @ResponseBody
	Response<User> updateSP(@PathVariable(value = "id") long id,
			@RequestBody(required = true) User reqBody,
			HttpServletRequest request) {
		Response<User> res = new Response<User>();
		try {
			reqBody.setModifiedBy(request.getUserPrincipal().getName());
			reqBody.setModifiedOn(System.currentTimeMillis());
			User userDetails = user.updateById(id, reqBody);
			if(userDetails != null){
			res.setStatusCode(HttpServletResponse.SC_OK);
			res.setResult(new User[] {userDetails});
			}else{
				res.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
				res.setStatusMsg("Not Found");
				res.setResult(null);
			}
			return res;
		} catch (MappingException me) {
			logger.error("Cannot map the field name " + me.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (JDBCException je) {
			logger.error("Unable to connect to database " + je.getMessage());
			res.setStatusMsg("FAILURE");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (DataIntegrityViolationException dive) {
			logger.error("Duplicate data " + dive.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		} catch (HibernateException he) {
			logger.error("Hibernate Connection " + he.getMessage());
			res.setStatusMsg("Internal Server Error");
			res.setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return res;
		}

	}

}
